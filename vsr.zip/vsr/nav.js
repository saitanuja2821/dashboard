import React from 'react';

const Navbar = () => {
  return (
    <header className="navbar">
      <h1>User Management Dashboard</h1>
      <div className="auth">
        <span>Welcome, User!</span>
        <button>Logout</button>
      </div>
    </header>
  );
};

export default Navbar;