import React, { useState } from 'react';

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [newUser , setNewUser ] = useState({ name: '', email: '', role: '', status: 'Active' });

  const addUser  = () => {
    setUsers([...users, newUser ]);
    setNewUser ({ name: '', email: '', role: '', status: 'Active' });
  };

  const deleteUser  = (index) => {
    const updatedUsers = users.filter((_, i) => i !== index);
    setUsers(updatedUsers);
  };

  return (
    <section id="users" className="user-management">
      <h2>User Management</h2>
      <div>
        <h3>Add New User</h3>
        <input
          type="text"
          placeholder="Name"
          value={newUser .name}
          onChange={(e) => setNewUser ({ ...newUser , name: e.target.value })}
        />
        <input
          type="email"
          placeholder="Email"
          value={newUser .email}
          onChange={(e) => setNewUser ({ ...newUser , email: e.target.value })}
        />
        <input
          type="text"
          placeholder="Role"
          value={newUser .role}
          onChange={(e) => setNewUser ({ ...newUser , role: e.target.value })}
        />
        <select
          value={newUser .status}
          onChange={(e) => setNewUser ({ ...newUser , status: e.target.value })}
        >
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
        <button onClick={addUser }>Add User</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <