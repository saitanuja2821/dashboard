import React from 'react';

const Sidebar = ({ setActiveSection }) => {
  return (
    <nav className="sidebar">
      <h2>Dashboard</h2>
      <ul>
        <li onClick={() => setActiveSection('users')}>Users</li>
        <li onClick={() => setActiveSection('roles')}>Roles</li>
        <li onClick={() => setActiveSection('permissions')}>Permissions</li>
      </ul>
    </nav>
  );
};

export default Sidebar;